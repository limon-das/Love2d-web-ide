
export type FileType = 'file' | 'folder';

export interface FileNode {
  name: string;
  path: string;
  type: FileType;
  content?: string;
  children?: FileNode[];
}

export interface Message {
  text: string;
  type: 'log' | 'error';
  timestamp: Date;
}
