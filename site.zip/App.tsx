
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { JSZip } from './services/jszip';
import type { FileNode, Message } from './types';
import { initialFiles } from './constants';
import Header from './components/Header';
import FileExplorer from './components/FileExplorer';
import EditorPanel from './components/EditorPanel';
import GameView from './components/GameView';
import Console from './components/Console';

declare global {
  interface Window {
    Love: (config: any) => Promise<any>;
    love: {
        quit: () => void;
    }
  }
}

const App: React.FC = () => {
  const [files, setFiles] = useState<FileNode[]>(initialFiles);
  const [activeFile, setActiveFile] = useState<string>('main.lua');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [loveInstance, setLoveInstance] = useState<any>(null);

  const findFile = (nodes: FileNode[], path: string): FileNode | null => {
    for (const node of nodes) {
      if (node.path === path) return node;
      if (node.type === 'folder' && node.children) {
        const found = findFile(node.children, path);
        if (found) return found;
      }
    }
    return null;
  };

  const currentFile = findFile(files, activeFile);
  const code = currentFile && currentFile.type === 'file' ? currentFile.content : '';

  const addMessage = useCallback((text: string, type: 'log' | 'error' = 'log') => {
    setMessages(prev => [...prev, { text, type, timestamp: new Date() }]);
  }, []);

  const handleCodeChange = (newCode: string) => {
    if (activeFile) {
      const updateNode = (nodes: FileNode[], path: string): FileNode[] => {
        return nodes.map(node => {
          if (node.path === path && node.type === 'file') {
            return { ...node, content: newCode };
          }
          if (node.type === 'folder' && node.children) {
            return { ...node, children: updateNode(node.children, path) };
          }
          return node;
        });
      };
      setFiles(prevFiles => updateNode(prevFiles, activeFile));
    }
  };
  
  const handleRun = useCallback(async () => {
    const loveContainer = document.getElementById('love-container');
    if (!loveContainer) {
      addMessage('Error: Game container element not found in the DOM.', 'error');
      return;
    }
    
    // Clear previous canvas if any
    loveContainer.innerHTML = '';
    
    addMessage('Starting game...');
    setIsRunning(true);

    const zip = new JSZip();
    
    const addFilesToZip = (nodes: FileNode[], pathPrefix = '') => {
      nodes.forEach(node => {
        const fullPath = pathPrefix ? `${pathPrefix}/${node.name}` : node.name;
        if (node.type === 'file') {
          zip.file(fullPath, node.content || '');
        } else if (node.type === 'folder' && node.children) {
          addFilesToZip(node.children, fullPath);
        }
      });
    };
    
    // If project is in a single root folder, use its contents.
    const filesToZip = files.length === 1 && files[0].type === 'folder' && files[0].children
        ? files[0].children
        : files;

    const mainLuaFile = findFile(filesToZip, 'main.lua');
    if(!mainLuaFile) {
        addMessage('Error: main.lua not found in project root.', 'error');
        setIsRunning(false);
        return;
    }
    
    addFilesToZip(filesToZip);

    try {
      const blob = await zip.generateAsync({ type: 'blob' });
      const loveUrl = URL.createObjectURL(blob);

      const instance = await window.Love({
        love: loveUrl,
        mount: loveContainer,
        print: (text: string) => addMessage(text, 'log'),
        onerror: (error: Error | string) => {
            const errorMessage = typeof error === 'string' ? error : error.message;
            addMessage(`LÖVE Error: ${errorMessage}`, 'error');
            setIsRunning(false);
        },
        onquit: () => {
            addMessage('Game stopped.');
            setIsRunning(false);
            setLoveInstance(null);
            const container = document.getElementById('love-container');
            if (container) {
                container.innerHTML = ''; // Clean up canvas on quit
            }
        }
      });
      setLoveInstance(instance);
      URL.revokeObjectURL(loveUrl);
    } catch (e: any) {
      addMessage(`Error creating LÖVE instance: ${e.message}`, 'error');
      setIsRunning(false);
    }
  }, [files, addMessage]);

  const handleStop = useCallback(() => {
    if (loveInstance && typeof window.love?.quit === 'function') {
        try {
            window.love.quit();
        } catch (e: any) {
             addMessage(`Error stopping game: ${e.message}`, 'error');
        }
    } else {
        addMessage('Game already stopped or could not be stopped.');
        setIsRunning(false);
        setLoveInstance(null);
        const container = document.getElementById('love-container');
        if (container) {
            container.innerHTML = '';
        }
    }
  }, [loveInstance, addMessage]);
  
  const handleDownload = async () => {
    addMessage('Packaging project into .love file...');
    const zip = new JSZip();
    
    const addFilesToZip = (nodes: FileNode[], pathPrefix = '') => {
        nodes.forEach(node => {
            const fullPath = pathPrefix ? `${pathPrefix}/${node.name}` : node.name;
            if (node.type === 'file') {
                zip.file(fullPath, node.content || '');
            } else if (node.type === 'folder' && node.children) {
                addFilesToZip(node.children, fullPath);
            }
        });
    };
    
    // If project is in a single root folder, use its contents.
    const filesToZip = files.length === 1 && files[0].type === 'folder' && files[0].children
        ? files[0].children
        : files;
        
    addFilesToZip(filesToZip);

    try {
        const blob = await zip.generateAsync({ type: 'blob' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'game.love';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
        addMessage('Project downloaded as game.love');
    } catch(e: any) {
        addMessage(`Error packaging project: ${e.message}`, 'error');
    }
  };

  const handleProjectLoad = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) {
      return;
    }
    addMessage("Loading project files...");
  
    const rootNodes: FileNode[] = [];
    const filePromises: Promise<void>[] = [];
  
    const addNodeByPath = (path: string, content: string) => {
      const parts = path.split('/').filter(p => p);
      let currentLevel = rootNodes;
      let currentPath = '';
  
      parts.forEach((part, index) => {
        const isLastPart = index === parts.length - 1;
        // Reconstruct the full path for the current node
        const nodePath = currentPath ? `${currentPath}/${part}` : part;
  
        let node = currentLevel.find(n => n.name === part);
  
        if (!node) {
          node = {
            name: part,
            path: nodePath,
            type: isLastPart ? 'file' : 'folder',
            ...(isLastPart ? { content } : { children: [] }),
          };
          currentLevel.push(node);
        }
        
        if (node.type === 'folder') {
          currentLevel = node.children!;
          currentPath = nodePath;
        }
      });
    };
  
    for (const file of Array.from(fileList)) {
      // The 'file' object from a directory upload has a non-standard 'webkitRelativePath'
      const relativePath = (file as any).webkitRelativePath;
      if (!relativePath) continue;

      const promise = new Promise<void>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          addNodeByPath(relativePath, content);
          resolve();
        };
        reader.onerror = (err) => reject(err);
        reader.readAsText(file);
      });
      filePromises.push(promise);
    }
  
    try {
      await Promise.all(filePromises);
      setFiles(rootNodes);
      
      let mainLuaPath = 'main.lua';
      // If the project is in a subfolder, find main.lua inside it
      if (rootNodes.length === 1 && rootNodes[0].type === 'folder') {
          mainLuaPath = `${rootNodes[0].path}/main.lua`;
      }
      
      const mainLuaFile = findFile(rootNodes, mainLuaPath);
      setActiveFile(mainLuaFile?.path || (rootNodes.find(f => f.type === 'file')?.path || ''));

      addMessage('Project loaded successfully!', 'log');
    } catch (error: any) {
      addMessage(`Error loading project: ${error.message}`, 'error');
    }
  };

  // Add a one-time welcome message
  useEffect(() => {
    addMessage('Welcome to the LÖVE 2D Web IDE!');
    addMessage('Write your code, or load a project, then press "Run".');
  }, [addMessage]);
  
  return (
    <div className="flex flex-col h-screen font-sans">
      <Header onRun={handleRun} onStop={handleStop} onDownload={handleDownload} isRunning={isRunning} />
      <div className="flex flex-1 overflow-hidden">
        <div className="w-1/5 bg-[#21222C] flex flex-col min-w-[200px]">
          <FileExplorer files={files} activeFile={activeFile} onSelectFile={setActiveFile} onProjectLoad={handleProjectLoad} />
        </div>
        <div className="w-2/5 flex flex-col min-w-[300px]">
          <EditorPanel code={code} onCodeChange={handleCodeChange} activeFile={activeFile} />
        </div>
        <div className="w-2/5 flex flex-col min-w-[300px]">
          <GameView isRunning={isRunning}/>
          <Console messages={messages} />
        </div>
      </div>
    </div>
  );
};

export default App;
