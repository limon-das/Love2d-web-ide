
import type { FileNode } from './types';

export const initialFiles: FileNode[] = [
  {
    name: 'main.lua',
    path: 'main.lua',
    type: 'file',
    content: `
function love.draw()
    -- Get window dimensions
    local w = love.graphics.getWidth()
    local h = love.graphics.getHeight()

    -- Display welcome message
    love.graphics.printf(
        'Hello from LÖVE 2D Web IDE!', 
        0, 
        h / 2 - 20, 
        w, 
        'center'
    )

    -- Draw a pulsing circle
    local pulse = math.abs(math.sin(love.timer.getTime() * 2))
    local r, g, b = 255, 75, 125 -- Pink/purple color
    love.graphics.setColor(r/255, g/255, b/255)
    love.graphics.circle(
        'fill', 
        w / 2, 
        h / 2 + 50, 
        20 + pulse * 10
    )

    -- Reset color
    love.graphics.setColor(1, 1, 1)
    
    print("Frame drawn at: " .. tostring(love.timer.getTime()))
end
`
  },
];
