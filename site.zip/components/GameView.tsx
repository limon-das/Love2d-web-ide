
import React from 'react';
import { Gamepad2 } from 'lucide-react';

interface GameViewProps {
  isRunning: boolean;
}

const GameView: React.FC<GameViewProps> = ({ isRunning }) => {
  return (
    <div className="flex-1 bg-black border-l border-b border-gray-700 relative">
      <div id="love-container" className="w-full h-full">
        {/* love.js will mount its canvas here */}
      </div>
      {!isRunning && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-80 text-gray-400">
          <Gamepad2 size={64} className="mb-4 text-gray-500" />
          <p className="text-lg">Game not running.</p>
          <p className="text-sm">Press "Run" to start.</p>
        </div>
      )}
    </div>
  );
};

export default GameView;
