import React, { useRef } from 'react';
import type { FileNode } from '../types';
import { FileText, Folder, UploadCloud } from 'lucide-react';

// Augment React's HTMLAttributes to include non-standard attributes for folder uploads.
declare module 'react' {
  interface InputHTMLAttributes<T> {
    directory?: string;
    webkitdirectory?: string;
  }
}

interface FileExplorerProps {
  files: FileNode[];
  activeFile: string;
  onSelectFile: (path: string) => void;
  onProjectLoad: (fileList: FileList | null) => void;
}

const FileNodeItem: React.FC<{ node: FileNode; activeFile: string; onSelectFile: (path: string) => void; level: number }> = ({ node, activeFile, onSelectFile, level }) => {
  const isActive = node.path === activeFile;
  const isFolder = node.type === 'folder';

  const handleClick = () => {
    if (!isFolder) {
      onSelectFile(node.path);
    }
  };

  return (
    <div>
      <div
        onClick={handleClick}
        className={`flex items-center px-2 py-1.5 cursor-pointer rounded-sm text-sm ${
          isActive ? 'bg-[#44475a] text-white' : 'hover:bg-[#343746]'
        } ${isFolder ? 'font-semibold text-gray-400 cursor-default' : ''}`}
        style={{ paddingLeft: `${level * 1 + 0.5}rem` }}
      >
        {isFolder ? <Folder size={16} className="mr-2 text-yellow-400 flex-shrink-0" /> : <FileText size={16} className="mr-2 text-cyan-400 flex-shrink-0" />}
        <span className="truncate">{node.name}</span>
      </div>
      {isFolder && node.children && (
        <div>
          {node.children.map(child => (
            <FileNodeItem key={child.path} node={child} activeFile={activeFile} onSelectFile={onSelectFile} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
};

const FileExplorer: React.FC<FileExplorerProps> = ({ files, activeFile, onSelectFile, onProjectLoad }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLoadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onProjectLoad(event.target.files);
    // Reset the input value to allow re-uploading the same folder
    if (event.target) {
      event.target.value = '';
    }
  };
  
  return (
    <div className="h-full overflow-y-auto flex flex-col">
       <div className="flex items-center justify-between p-2 border-b border-gray-700">
        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Project Files</h2>
        <button 
          onClick={handleLoadClick} 
          title="Load Project Folder"
          className="flex items-center px-2 py-1 bg-gray-600 hover:bg-gray-500 rounded-md transition-colors duration-200 text-xs"
        >
          <UploadCloud size={14} className="mr-1.5" />
          Load
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          // These attributes are key for folder uploads
          webkitdirectory=""
          directory=""
          multiple
        />
       </div>
      <div className="p-1 flex-1">
        {files.length > 0 ? files.map(node => (
          <FileNodeItem key={node.path} node={node} activeFile={activeFile} onSelectFile={onSelectFile} level={0} />
        )) : (
          <div className="p-4 text-center text-sm text-gray-500">
            <p>No project loaded.</p>
            <p>Click "Load" to open a project folder.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FileExplorer;