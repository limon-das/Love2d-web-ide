
import React, { useEffect, useRef } from 'react';
import type { Message } from '../types';
import { Terminal, AlertTriangle } from 'lucide-react';

interface ConsoleProps {
  messages: Message[];
}

const Console: React.FC<ConsoleProps> = ({ messages }) => {
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  return (
    <div className="h-1/3 flex flex-col bg-[#21222C] border-l border-t border-gray-700">
      <div className="flex items-center p-2 bg-[#191a21] text-sm font-semibold text-gray-300 border-b border-gray-700">
        <Terminal size={16} className="mr-2" />
        Console
      </div>
      <div className="flex-1 p-2 overflow-y-auto font-mono text-xs">
        {messages.map((msg, index) => (
          <div key={index} className={`flex items-start ${msg.type === 'error' ? 'text-red-400' : 'text-gray-400'}`}>
            <span className="mr-2">
              {msg.type === 'error' && <AlertTriangle size={12} className="inline-block" />}
            </span>
            <span className="flex-1">{msg.text}</span>
          </div>
        ))}
        <div ref={endOfMessagesRef} />
      </div>
    </div>
  );
};

export default Console;
