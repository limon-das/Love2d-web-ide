
import React from 'react';
import Editor from 'react-simple-code-editor';
import Prism from 'prismjs';
import 'prismjs/components/prism-lua';

interface EditorPanelProps {
  code: string;
  onCodeChange: (code: string) => void;
  activeFile: string;
}

const EditorPanel: React.FC<EditorPanelProps> = ({ code, onCodeChange, activeFile }) => {
  const highlightWithLineNumbers = (input: string) =>
    Prism.highlight(input, Prism.languages.lua, 'lua')
      .split('\n')
      .map((line: string, i: number) => `<span class='prism-editor__line-number'>${i + 1}</span>${line}`)
      .join('\n');
  
  const fileName = activeFile.split('/').pop() || 'No file selected';

  return (
    <div className="flex flex-col h-full bg-[#282a36]">
      <div className="bg-[#191a21] p-2 text-sm text-gray-400 border-b border-l border-gray-700 truncate">
        {fileName}
      </div>
      <div className="flex-1 overflow-auto editor-container line-numbers">
        <Editor
          value={code}
          onValueChange={onCodeChange}
          highlight={(code) => highlightWithLineNumbers(code)}
          padding={10}
          textareaClassName="prism-editor__textarea"
          preClassName="prism-editor__pre"
          className="prism-editor"
          disabled={!activeFile}
        />
      </div>
    </div>
  );
};

export default EditorPanel;
