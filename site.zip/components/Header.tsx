
import React from 'react';
import { Play, Square, Download, Code } from 'lucide-react';

interface HeaderProps {
  onRun: () => void;
  onStop: () => void;
  onDownload: () => void;
  isRunning: boolean;
}

const Header: React.FC<HeaderProps> = ({ onRun, onStop, onDownload, isRunning }) => {
  return (
    <header className="bg-[#191a21] text-white flex items-center justify-between p-2 border-b border-gray-700 shadow-md z-10">
      <div className="flex items-center">
        <Code className="w-8 h-8 text-[#ff79c6] mr-3" />
        <h1 className="text-xl font-bold">LÖVE 2D Web IDE</h1>
      </div>
      <div className="flex items-center space-x-3">
        {!isRunning ? (
          <button
            onClick={onRun}
            className="flex items-center px-4 py-2 bg-green-500 hover:bg-green-600 rounded-md transition-colors duration-200"
          >
            <Play className="w-5 h-5 mr-2" />
            Run
          </button>
        ) : (
          <button
            onClick={onStop}
            className="flex items-center px-4 py-2 bg-red-500 hover:bg-red-600 rounded-md transition-colors duration-200"
          >
            <Square className="w-5 h-5 mr-2" />
            Stop
          </button>
        )}
        <button
          onClick={onDownload}
          className="flex items-center px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-md transition-colors duration-200"
        >
          <Download className="w-5 h-5 mr-2" />
          Download .love
        </button>
      </div>
    </header>
  );
};

export default Header;
